$(document).ready(function(){
		//数据个数
		var number=[];
		var tr=$("table>.thead>.tr1");
		for(var i=0;i<tr.length;i++){
			number.push([tr.eq(i)]);
		}
		console.log(number);
		//分页
//		$('#page').pagination({
//		    dataSource:number,//数据源（总个数）
//		    pageSize:10,//每页展示10条数据为一页
//		    callback: function(data, pagination) {
//		        //数据处理
//		    }
//		})
})
